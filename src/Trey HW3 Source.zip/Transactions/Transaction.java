package Transactions;
import Products.Product;


public abstract class Transaction {

	protected Product _product;
	
	public Transaction(Product product)
	{
		_product = product;
	}

	public Product getProduct() {
	    return _product;
	}
	
	
	
}
